const Usuarios = require('./Usuarios');
const Carteira = require('./Carteira');
const Receitas = require('./Receitas');
const Despesas = require('./Despesas');

module.exports = {
    Usuarios,
    Carteira,
    Receitas,
    Despesas,
}